<?php include "header.php" ?>
<!-- End Header -->

<!-- Start Breadcrumb 
    ============================================= -->
<div class="breadcrumb-area gradient-bg bg-cover shadow dark text-light text-center"
    style="background-image: url(assets/img/about_mdn2.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <h1>Life Insurance</h1>
                <ul class="breadcrumb">
                    <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
                    <!-- <li><a href="#">Pages</a></li> -->
                    <li class="active">Services</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- End Breadcrumb -->

<!-- Start Services
    ============================================= -->
<div class="services-area default-padding">
    <div class="container">
        <div class="services-box">
            <div class="row">
                <div class="col-lg-3 tab-navs">
                    <ul id="tabs" class="nav nav-tabs">
                        <li class="nav-item">
                            <a href="post.php" class="nav-link"><i class="fas fa-angle-right"></i>
                                Post-Office Savings Schemes</a>
                        </li>
                        <li class="nav-item">
                            <a href="lic.php" class="active nav-link"><i class="fas fa-angle-right"></i> Life
                                Insurance</a>
                        </li>
                        <li class="nav-item">
                            <a href="gic.php" class="nav-link"> <i class="fas fa-angle-right"></i> General
                                Insurance</a>
                        </li>
                        <!-- <li class="nav-item">
                                <a href="alluminium.php" class="nav-link"> <i
                                        class="fas fa-angle-right"></i> Alluminium Section</a>
                            </li> -->
                    </ul>
                </div>
                <div class="col-lg-9">
                    <div class="col-lg-7 col-md-12 info" style="float:left;">
                        <h3>Life Insurance</h3>
                        <p>

                            How it works
                            You choose a policy and pay premiums to an insurer.
                            If you die while the policy is active, the insurer pays a death benefit to the beneficiaries
                            you've named in the contract.
                            This death benefit can be used for a variety of financial needs, such as replacing lost
                            income, paying for your children's education, or settling your debts.
                            <!-- <ol>
                              
                                <li>
                                    Mix mud/sand, cement & graval (GSB), properly with Grader
                                </li>
                               
                                <li>
                                    Back-to-Back Mix all Ingredients with GRADER MACHINE homogenously
                                </li>
                               
                                <li>
                                    Compact with 10/15 Tons Roller
                                    First Compact on sloping of one side
                                    Then Compact on sloping of other side
                                    Then Compact from centre (to develop proper slop)
                                </li>
                               
                               
                             
                            </ol> -->
                        </p>
                        <ul class="my" style="color: darkmagenta;">
                            <li><a href="term.php">Term Insurance</a></li>
                            <li><a href="retirement.php"> Retirement Policy</a></li>
                            <li><a href="money-back.php">Money Back Policy</a></li>
                            <li><a href="child.php">Child Policy</a></li>
                            <li><a href="unit-linked.php">Unit Linked Policy</a></li>
                        </ul>

                        <!-- <a class="btn-simple" href="#"><i class="fas fa-angle-right"></i> Read More</a> -->
                    </div>

                    <div class="col-lg-5 col-md-12 thumb" style="float:right;">
                        <img src="assets/img/gvan-Shanti.png" alt="Thumb">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Services Area -->

<!-- Start Work With Us 
    ============================================= -->
<!-- <div class="work-with-us-area bg-gray default-padding">
        <div class="container">
            <div class="content-box">
                <div class="row align-center">
                    <div class="col-lg-5">
                        <div class="heading-info">
                            <h5>Working with Us</h5>
                            <h2>Contractors & Construction Managers Since 1989</h2>
                            <a href="#" class="btn angle btn-theme effect btn-md">Get a Quote</a>
                        </div>
                    </div>
                    <div class="col-lg-7 fun-facts-items text-center">
                        <div class="row">
                            <div class="col-lg-4 col-md-4">
                                <div class="fun-fact">
                                    <h4>Ongoing Projects</h4>
                                    <div class="timer" data-to="28" data-speed="5000">28</div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4">
                                <div class="fun-fact">
                                    <h4>End Project</h4>
                                    <div class="timer" data-to="56" data-speed="5000">56</div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4">
                                <div class="fun-fact">
                                    <h4>Upcomming Project</h4>
                                    <div class="timer" data-to="20" data-speed="5000">20</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
<!-- End Work With Us -->

<!-- Start Work Porccess 
    ============================================= -->
<!-- <div class="work-process-area relative default-padding bottom-less bg-fixed" style="background-image: url(assets/img/bg.png);">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h4>How we work</h4>
                        <h2>Work Process</h2>
                        <p>
                            While mirth large of on front. Ye he greater related adapted proceed entered an. Through it examine express promise no. Past add size game cold girl off how old
                        </p>
                    </div>
                </div>
            </div>
            <div class="work-pro-items">
                <div class="row">
                    <div class="col-lg-4 col-md-6 single-item">
                        <div class="item">
                            <div class="item-inner">
                                <i class="flaticon-ruler"></i>
                                <h4>Design <span>01</span></h4>
                                <p>
                                    Preserved believing extremity. Easy mr pain felt in. Too northward affection additions nay. He no an nature ye talent houses wisdom vanity denied. 
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 single-item">
                        <div class="item">
                            <div class="item-inner">
                                <i class="flaticon-creativity"></i>
                                <h4>Planning <span>02</span></h4>
                                <p>
                                    Preserved believing extremity. Easy mr pain felt in. Too northward affection additions nay. He no an nature ye talent houses wisdom vanity denied. 
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 single-item">
                        <div class="item">
                            <div class="item-inner">
                                <i class="flaticon-house"></i>
                                <h4>Devolepment <span>03</span></h4>
                                <p>
                                    Preserved believing extremity. Easy mr pain felt in. Too northward affection additions nay. He no an nature ye talent houses wisdom vanity denied. 
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
<!-- End Work Porccess -->

<!-- Start Testimonials Area 
    ============================================= -->

<!-- End Testimonials Area -->

<!-- Start FAQ 
    ============================================= -->
<!-- <div class="faq-area default-padding">
        <div class="container">
            <div class="faqs">
                <div class="row">
                    <div class="col-lg-7">
                        <div class="accordion" id="accordionExample">
                            <div class="card">
                                <div class="card-header" id="headingOne">
                                    <h4 class="mb-0" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        <span>01</span> What is the Decent Work Check Survey?
                                    </h4>
                                </div>

                                <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                                    <div class="card-body">
                                        <p>
                                            General windows effects not are drawing man garrets. Common indeed garden you his ladies out yet. Preference imprudence contrasted to remarkably in on. Taken now you him trees tears any. Her object giving end sister except oppose. 
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingTwo">
                                    <h4 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        <span>02</span> What are the Factory Pages?
                                    </h4>
                                </div>
                                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                                    <div class="card-body">
                                        <p>
                                            General windows effects not are drawing man garrets. Common indeed garden you his ladies out yet. Preference imprudence contrasted to remarkably in on. Taken now you him trees tears any. Her object giving end sister except oppose. 
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingThree">
                                    <h4 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                        <span>03</span> Can I participate in the Survey?
                                    </h4>
                                </div>
                                <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                                    <div class="card-body">
                                        <p>
                                            General windows effects not are drawing man garrets. Common indeed garden you his ladies out yet. Preference imprudence contrasted to remarkably in on. Taken now you him trees tears any. Her object giving end sister except oppose. 
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-5">
                        <img src="assets/img/illustration/2.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div> -->
<!-- End FAQ -->

<!-- Start Footer 
    ============================================= -->
<?php include "footer.php" ?>
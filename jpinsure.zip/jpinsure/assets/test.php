#cb011d
#ede301
#f6e000
#ffe902

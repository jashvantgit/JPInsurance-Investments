<!DOCTYPE html>
<html lang="en">

<head>
    <!-- ========== Meta Tags ========== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">

    <!-- ========== Page Title ========== -->
    <title>I M Construction</title>

    <!-- ========== Favicon Icon ========== -->
    <link rel="shortcut icon" href="assets/img/favicon1.png" type="image/x-icon">

    <!-- ========== Start Stylesheet ========== -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.min.css" rel="stylesheet" />
    <link href="assets/css/flaticon-set.css" rel="stylesheet" />
    <link href="assets/css/magnific-popup.css" rel="stylesheet" />
    <link href="assets/css/owl.carousel.min.css" rel="stylesheet" />
    <link href="assets/css/owl.theme.default.min.css" rel="stylesheet" />
    <link href="assets/css/animate.css" rel="stylesheet" />
    <link href="assets/css/themify-icons.css" rel="stylesheet" />
    <link href="assets/css/bootsnav.css" rel="stylesheet" />
    <link href="style.css" rel="stylesheet">
    <link href="assets/css/responsive.css" rel="stylesheet" />
    <!-- ========== End Stylesheet ========== -->

    <!-- ========== Google Fonts ========== -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800&display=swap"
        rel="stylesheet">

    <style type="">
        @media only screen and (max-width: 600px) {
                /* .navbar-brand > img {
                    height: 73px !important;
                } */
                .navbar-brand > img {
    display: initial;
    height: 90px !important;
    width: 150px !important;
    padding: 10px 0px 10px 33px!important;
}
            }
        </style>


</head>

<body>

    <div class="top-bar-area overflow-hidden  text-light">
    <div class="container">
        <div class="row align-center">

            <div class="col-lg-9 info">
                <div class="info box item-flex">
                    <ul class="list">
                        <li>
                            <i style="color: #ffffff;" class="fas fa-map-marker-alt"></i>
                            Ahmedabad-380015
                        </li>
                        <li>
                            <a href="mailto: im0066@yahoo.co.in"><i style="color: #ffffff;" class="fas fa-envelope-open"></i>
                                im0066@yahoo.co.in</a>
                        </li>
                    </ul>
                    <ul class="social">
                        <li class="facebook">
                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                        </li>
                        <li class="twitter">
                            <a href="#"><i class="fab fa-twitter"></i></a>
                        </li>
                        <li class="pinterest">
                            <a href="#"><i class="fab fa-instagram"></i></a>
                        </li>
                        <!-- <li class="linkedin">
                                <a href="#"><i class="fab fa-linkedin-in"></i></a>
                            </li> -->
                    </ul>
                </div>
            </div>

            <div class="col-lg-3 text-right button-box">
                <div class="button">
                    <a href="tel:9898441117"><i class="fas fa-phone"></i> +91-98984 41117</a>
                </div>
            </div>

        </div>
    </div>
</div>
<!-- End Header Top -->

<!-- Header 
    ============================================= -->
<header id="home">

    <!-- Start Navigation -->
    <nav class="navbar navbar-default attr-border navbar-sticky bootsnav">

        <div class="container">

            <!-- Start Header Navigation -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.php">
                    <img src="assets/img/logo1.png" class="logo" alt="Logo">
                </a>
            </div>
            <!-- End Header Navigation -->

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="navbar-menu">
                <ul class="nav navbar-nav navbar-right" data-in="#" data-out="#">
                    <li class="dropdown">
                        <a href="index.php">Home</a>
                        <!-- <ul class="dropdown-menu">
                                <li><a href="index.html">Home Version One</a></li>
                                <li><a href="index-2.html">Home Version Two</a></li>
                                <li><a href="index-3.html">Home Version Three</a></li>
                                <li><a href="index-4.html">Home Version Four</a></li>
                            </ul> -->
                    </li>
                    <li class="dropdown">
                        <a href="about-us.php">About Us</a>
                        <!-- <ul class="dropdown-menu">
                                <li><a href="about-us.html">About Us</a></li>
                                <li><a href="contact.html">Contact Us</a></li>
                                <li><a href="faq.html">Faq</a></li>
                                <li><a href="404.html">Error Page</a></li>
                            </ul> -->
                    </li>

                    <li class="dropdown">
                        <a href="ind-bld.php">Service</a>
                        <!-- <ul class="dropdown-menu">
                                <li><a href="services.html">Services Version One</a></li>
                                <li><a href="services-2.html">Services Version Two</a></li>
                                <li><a href="services-3.html">Services Version Three</a></li>
                                <li><a href="services-details.html">Services Details</a></li>
                            </ul> -->
                    </li>
                    <li class="dropdown">
                        <a href="client_list.php">Client List</a>
                    </li>
                    <li class="dropdown">
                        <a href="gallery.php">Gallery</a>
                    </li>
                    <!-- <li class="dropdown">
                            <a href="#">Inquiry</a> -->
                    <!-- <ul class="dropdown-menu">
                                <li><a href="team.html">Team Grid</a></li>
                                <li><a href="team-carousel.html">Team Carousel</a></li>
                            </ul> -->
                    <!-- </li> -->
                    <!-- <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" >Blog</a>
                            <ul class="dropdown-menu">
                                <li><a href="blog-standard.html">Blog Standard</a></li>
                                <li><a href="blog-with-sidebar.html">Blog With Sidebar</a></li>
                                <li><a href="blog-2-colum.html">Blog Grid Two Colum</a></li>
                                <li><a href="blog-3-colum.html">Blog Grid Three Colum</a></li>
                                <li><a href="blog-single.html">Blog Single</a></li>
                                <li><a href="blog-single-with-sidebar.html">Blog Single With Sidebar</a></li>
                            </ul>
                        </li> -->
                    <li>
                        <a href="contact.php">Contact Us</a>
                    </li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </div>

    </nav>
    <!-- End Navigation -->

</header>
    <!-- Start Header Top 
    ============================================= -->

    <!-- End Header -->

    <!-- Start Banner 
    ============================================= -->
    <div class="banner-area inc-content center-responsive text-large">
        <div id="bootcarousel" class="carousel slide text-light carousel-fade animate_text" data-ride="carousel">
            <!-- Wrapper for slides -->
            <div class="carousel-inner carousel-zoom">
                <div class="carousel-item active">
                    <div class="slider-thumb bg-cover" style="background-image: url(assets/img/banner_3.jpeg);"></div>
                    <div class="box-table shadow dark">
                        <div class="box-cell">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-7 ">
                                        <div class="content">
                                            <h2 style="font-size: 40px;" data-animation="animated slideInRight">Welcome
                                                To</h2>
                                            <h2 style="font-size: 60px;" data-animation="animated slideInRight">I M
                                                Construction</h2>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="slider-thumb bg-cover" style="background-image: url(assets/img/banner_2.jpeg);"></div>
                    <div class="box-table shadow dark">
                        <div class="box-cell">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-8 ">
                                        <div class="content">
                                            <!-- <h2 data-animation="animated slideInDown">Modern technology</h2> -->
                                            <!-- <p data-animation="animated slideInLeft">
                                                 Wound use found hoped. Of distrusts immediate enjoyment curiosity do. Marianne numerous saw thoughts the humoured. 
                                            </p>
                                            <div class="slider-button">
                                                <a data-animation="animated slideInUp" class="btn btn-theme effect btn-md angle" href="#">View Projects</a>
                                            </div> -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="slider-thumb bg-cover" style="background-image: url(assets/img/banner_1.jpeg);"></div>
                    <div class="box-table shadow dark">
                        <div class="box-cell">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-8 ">
                                        <div class="content">
                                            <!-- <h2 data-animation="animated slideInLeft">Modern technology</h2> -->
                                            <!-- <p data-animation="animated slideInLeft">
                                                 Wound use found hoped. Of distrusts immediate enjoyment curiosity do. Marianne numerous saw thoughts the humoured. 
                                            </p>
                                            <div class="slider-button">
                                                <a data-animation="animated slideInUp" class="btn btn-theme effect btn-md angle" href="#">View Projects</a>
                                            </div> -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Wrapper for slides -->

            <!-- Left and right controls -->
            <a class="left carousel-control light" href="#bootcarousel" data-slide="prev">
                <i class="fa fa-angle-left"></i>
                <span class="sr-only">Previous</span>
            </a>
            <a class="right carousel-control light" href="#bootcarousel" data-slide="next">
                <i class="fa fa-angle-right"></i>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>
    <!-- End Banner -->

    <!-- Start Our Features
    ============================================= -->
    <div class="features-area multi-option default-padding-bottom">
        <div class="container">

        </div>
    </div>
    <!-- End Our Features -->

    <!-- Start Our About
    ============================================= -->
    <div class="about-area default-padding-bottom">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 info-content">
                    <h2>
                        <strong>23</strong> <span>Years Work experience in Manufacturing</span>
                    </h2>
                    <p>
                        We, I M Construction, established in the Many year, are considered to be one of the leading
                        service providers of Many type
                        of services. Inclusive of Add Industrial & Building constructions, Road Construction, and Structural repairing & waterproofing etc.
                        we offer a wide range of above services. These services are highly appreciated among our patrons
                        for their effectiveness and timely execution. Rendered by us at cost effective prices, these
                        services are highly demanded among our patrons across the nation.
                    </p>
                    <blockquote>
                        <p>
                            In addition to this, the offered these services are rendered by us in user-defined
                            specifications. Used in various industries, office, hotel & residence these services are
                            highly appreciated and valued among our clients across the world. We render different
                            services to meet the desires and expectations of our clients as well as maintain long term
                            associations with them.
                        </p>
                        <!-- <span>Founder OF <strong>Factry</strong></span> -->
                    </blockquote>
                    <a href="about-us.php" class="btn btn-dark border btn-md" data-animation="animated slideInUp">Read
                        More</a>
                </div>
                <div class="col-lg-6 thumb-box">
                    <div class="thumb">
                        <img src="assets/img/about.jpeg" alt="Thumb">
                        <!-- <div class="video bg-cover" style="background-image: url(assets/img/800x800.png);">
                            <a href="https://www.youtube.com/watch?v=owhuBrGIOsE" class="popup-youtube video-play-button">
                                <i class="ti-control-play"></i>
                            </a>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Our About -->

    <!-- Start Services 
    ============================================= -->
    <div class="services-area icon-only text-light text-center bg-dark default-padding bottom-less">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h4>What We Do</h4>
                        <h2>Our Service</h2>
                        <!-- <p>
                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                        </p> -->
                    </div>
                </div>
            </div>
            <div class="services-box">
                <div class="row">
                    <!-- Single Item -->
                    <div class="single-item col-lg-4 col-md-6">
                        <div class="item">
                            <p>
                                <!-- Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                                has been the industry's standard dummy -->
                                <!-- Based on the site and building plan, necessary excavations, leveling,
                                 and filling can be undergone to prepare the site. -->
                                 The design of a building begins with its future user or owner, who has in mind a perceived 
                                 need for the structure, as well as a specific site and a general idea of its projected cost.
                                  <!-- The user, or client, brings these facts to a team of design professionals composed of 
                                  architects and engineers, who can develop from them a set of construction documents 
                                  that define  the proposed building exactly -->
                                  and from which it can be constructed.
                                <!-- Exhaust can create a fire hazard if it is not adequately vented and may also pose risks to human health. -->
                            </p>
                            <div class="bottom-info">
                                <i class="fa fa-industry"></i>
                                <h4>
                                    <!-- <a href="#"> -->
                                    <!-- Exhaust Ducting System -->
                                     Industrial & Building construction
                                    <!-- </a> -->
                                </h4>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Item -->
                    <!-- Single Item -->
                    <div class="single-item col-lg-4 col-md-6">
                        <div class="item">
                            <p>
                            <!-- Road construction is the establishment of an engineered, unbroken right-of-way or roadbed that overcomes
                             geographical barriers and has levels low enough to allow for car or foot 
                             traffic, and is needed to follow legal or official norms. -->
                             When constructing a new road, whether out of asphalt or concrete, it is necessary to produce a pavement 
                             structure that is very well-bonded, starting with a solid foundation layer and progressing all the way
                              up to a surface course that is properly levelled. 
                                <!-- Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                                has been the industry's standard dummy -->
                                <!-- Invisible grilles, however are of a different variant. You can bet that it will also come with a hefty and innovative price.  -->
                            </p>
                            <div class="bottom-info">
                                <i class="fa fa-barcode"></i>
                                <h4>
                                    <!-- <a href="#"> -->
                                    Road Construction
                                    <!-- </a> -->
                                </h4>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Item -->

                    <!-- Single Item -->

                    <!-- End Single Item -->
                    <!-- Single Item -->
                    <div class="single-item col-lg-4 col-md-6">
                        <div class="item">
                            <p>
                            Structural Repairs means only repairs to the foundations, the structural subfloors,
                             columns and beams and the structural portions of bearing walls and roofs of the 
                             Premises and specifically excludes maintenance of every kind.
                                <!-- Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                                has been the industry's standard dummy -->
                                <!-- Aluminium handle profile is usually considered a lightweight material but it is in fact extremely strong and versatile. -->
                            </p>
                            <div class="bottom-info">
                                <i class="fa fa-list-alt"></i>
                                <h4>
                                    <!-- <a href="#"> -->
                                    Structural repairing & waterproofing
                                    <!-- </a> -->
                                </h4>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Item -->
                </div>
            </div>
        </div>
    </div>
    <!-- End Services -->

    <!-- Start Projects Area 
    ============================================= -->
    <!-- <div class="projects-area default-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="project-item projects-carousel owl-carousel owl-theme">
                        <div class="item">
                            <div class="row align-center">
                                <div class="col-lg-6 info">
                                    <h4>Running Prjects</h4>
                                    <h2><a href="#">Invisible Grill</a></h2>
                                    <p>
                                        Hope they dear who its bred. Smiling nothing affixed he carried it clothes calling he no. Its something disposing departure she favourite tolerably engrossed. Truth short folly court why she their balls.
                                    </p>
                                    <ul>
                                        <li>
                                            <h5>Project Type</h5>
                                            <span>Factory</span>
                                        </li>
                                        <li>
                                            <h5>Duration</h5>
                                            <span>5 year</span>
                                        </li>
                                        <li>
                                            <h5>Budget</h5>
                                            <span>15m</span>
                                        </li>
                                    </ul>
                                </div>
                                <div class="col-lg-6 thumb-box">
                                    <div class="thumb">
                                        <img src="assets/img/img_1running_project.jpeg" alt="Thumb">
                                        <a href="https://www.youtube.com/watch?v=RprMgAcrpmg" class="popup-youtube"><i class="fas fa-video"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                       
                        <div class="item">
                            <div class="row align-center">
                                <div class="col-lg-6 info">
                                    <h4>Running Prjects</h4>
                                    <h2><a href="#">Industrial Shed</a></h2>
                                    <p>
                                        Hope they dear who its bred. Smiling nothing affixed he carried it clothes calling he no. Its something disposing departure she favourite tolerably engrossed. Truth short folly court why she their balls.
                                    </p>
                                    <ul>
                                        <li>
                                            <h5>Project Type</h5>
                                            <span>Energy</span>
                                        </li>
                                        <li>
                                            <h5>Duration</h5>
                                            <span>8 year</span>
                                        </li>
                                        <li>
                                            <h5>Budget</h5>
                                            <span>27m</span>
                                        </li>
                                    </ul>
                                </div>
                                <div class="col-lg-6 thumb-box">
                                    <div class="thumb">
                                        <img src="assets/img/ind_4running_prodject.jpeg" alt="Thumb">
                                        <a href="https://www.youtube.com/watch?v=RprMgAcrpmg" class="popup-youtube"><i class="fas fa-video"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                      
                        <div class="item">
                            <div class="row align-center">
                                <div class="col-lg-6 info">
                                    <h4>Running Prjects</h4>
                                    <h2><a href="#">Exhaust Ducting System</a></h2>
                                    <p>
                                        Hope they dear who its bred. Smiling nothing affixed he carried it clothes calling he no. Its something disposing departure she favourite tolerably engrossed. Truth short folly court why she their balls.
                                    </p>
                                    <ul>
                                        <li>
                                            <h5>Project Type</h5>
                                            <span>Machine</span>
                                        </li>
                                        <li>
                                            <h5>Duration</h5>
                                            <span>3 year</span>
                                        </li>
                                        <li>
                                            <h5>Budget</h5>
                                            <span>10m</span>
                                        </li>
                                    </ul>
                                </div>
                                <div class="col-lg-6 thumb-box">
                                    <div class="thumb">
                                        <img src="assets/img/running_project.jpg" alt="Thumb">
                                        <a href="https://www.youtube.com/watch?v=RprMgAcrpmg" class="popup-youtube"><i class="fas fa-video"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
    <!-- End Projects Area -->

    <!-- Start Why Chose Us 
    ============================================= -->
    <div class="why-us-area default-padding bg-gray">
        <!-- Fixed Thumb -->
        <div class="fixed-thumb bg-cover" style="background-image: url(assets/img/wearebest.jpeg);"></div>
        <!-- End Fixed Thumb -->
        <div class="container">
            <div class="row">
                <div class="col-lg-6 offset-lg-6 info">
                    <div class="content">
                        <h5>Dream big and dare to success</h5>
                        <h2>We're The <span>Best Service Provider</span> </h2>
                        <ul>
                            <li>
                                <h5>Quality</h5>
                                <p>
                                    We have got an in depth and thorough Quality Control Manual available to all
                                    customers that require verification of our high level of quality standards. The
                                    manual covers everything from our receiving process, to production standards, to our
                                    shipping and processes and ensures that the product you receive will be high quality
                                    and accurate to your specifications.
                                </p>
                            </li>
                            <li>
                                <h5>Our Mission</h5>
                                <p>
                                    The I M Construction team will find solutions through the cumulative effect of small
                                    improvements and flexible internal efficiencies to increase value and build
                                    partnerships.
                                </p>
                            </li>
                            <li>
                                <h5>CLIENT SATISFACTION</h5>
                                <p>
                                    I M Construction is permeated by a focus on customer needs, leading technologies and
                                    industrial craftsmanship. The ultimate responsibility of ensuring customer
                                    satisfaction lies with each respective, work continuously to meet customer
                                    expectations and deliver products & services of high and consistent quality.
                                </p>
                            </li>
                        </ul>
                        <!-- <a class="btn circle btn-theme angle effect btn-md" href="#">Start a Projects</a> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Why Chose Us -->

    <!-- Start Achivement 
    ============================================= -->
    <div class="achivement-area full bg-light default-padding">
        <div class="container">
            <!-- Fixed Thumb -->
            <div class="fixed-thumb">
                <img src="assets/img/map.svg" alt="Fixed map">
            </div>
            <!-- End Fixed Thumb -->
            <div class="row">
                <div class="col-lg-4 single-item">
                    <div class="fun-fact">
                        <div class="counter">
                            <div class="count">
                                <div class="timer" data-to="35" data-speed="2000"></div>
                            </div>
                        </div>
                        <div class="info">
                            <h5>Staff</h5>
                            <!-- <p>
                                Plan upon yet way get cold spot its week. Almost do am or limits.
                            </p> -->
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 single-item">
                    <div class="fun-fact">
                        <div class="counter">
                            <div class="count">
                                <div class="timer plus" data-to="280" data-speed="2000"></div>
                            </div>
                        </div>
                        <div class="info">
                            <h5>Clients</h5>
                            <!-- <p>
                                Plan upon yet way get cold spot its week. Almost do am or limits.
                            </p> -->
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 single-item">
                    <div class="fun-fact">
                        <div class="counter">
                            <div class="count">
                                <div class="timer" data-to="360" data-speed="2000"></div>
                            </div>
                        </div>
                        <div class="info">
                            <h5>Projects</h5>
                            <!-- <p>
                                Plan upon yet way get cold spot its week. Almost do am or limits.
                            </p> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Achivement -->

    <!-- Start Team Area 
    ============================================= -->

    <!-- End Team Area -->

    <!-- Start Testimonials Area 
    ============================================= -->
    <div class="testimonials-area default-padding">
        <div class="container">
            <div class="testimonial-items">
                <div class="row">
                    <div class="col-lg-5 title">
                        <h2>What Customers Say</h2>
                        <p>
                            See the results of our latest Customer Satisfaction Survey and key customer testimonials on
                            how we build strong working relationships with an understanding of individual need and
                            market knowledge.
                        </p>
                        <!-- <a class="btn circle btn-theme angle effect btn-md" href="#">View All</a> -->
                    </div>
                    <div class="col-lg-7 testimonial-box">
                        <div class="testimonial-content testimonials-carousel owl-carousel owl-theme">
                            <!-- Single Item -->
                            <!-- <div class="item">
                                <p>
                                    Trust me I M Construction has the best machines. The best machine can give the
                                    best output that the client wants.
                                </p>
                                <div class="provider">
                                    <div class="thumb">
                                        <img src="assets/img/test_moni.jpg" alt="Thumb">
                                    </div>
                                    <div class="info">
                                        <h5>Jayesh Mathur</h5> -->
                                        <!-- <span>Architect</span> -->
                                    <!-- </div>
                                </div>
                            </div> -->
                            <!-- End Single Item -->
                            <!-- Single Item -->
                            <!-- <div class="item">
                                <p>
                                    I feel very happy and be proud to connect with this industry. I presume this is a
                                    very aggressive and professional industry. I wish very good luck & success for this
                                    industry
                                </p>
                                <div class="provider">
                                    <div class="thumb">
                                        <img src="assets/img/test_moni.jpg" alt="Thumb">
                                    </div>
                                    <div class="info">
                                        <h5>Maunish Bansal</h5> -->
                                        <!-- <span>Designer</span> -->
                                    <!-- </div>
                                </div>
                            </div> -->
                            <!-- End Single Item -->
                                <!-- Single Item -->
                                <div class="item">
                                <p>
                                Working Process & System is awesome. 
                                </p>
                                <div class="provider">
                                    <div class="thumb">
                                        <img src="assets/img/test_moni.jpg" alt="Thumb">
                                    </div>
                                    <div class="info">
                                        <h5>Modern Builders - Bhavin Adhiya</h5>
                                        <!-- <span>Designer</span> -->
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Item -->
                                <!-- Single Item -->
                                <div class="item">
                                <p>
                                They have all old employees & agencies & without any tention they have completed work.

                                </p>
                                <div class="provider">
                                    <div class="thumb">
                                        <img src="assets/img/test_moni.jpg" alt="Thumb">
                                    </div>
                                    <div class="info">
                                        <h5>Swagat -3 Kuha-Kathwada - Harshad Patel</h5>
                                        <!-- <span>Designer</span> -->
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Item -->
                                <!-- Single Item -->
                                <div class="item">
                                <p>
                                We got this agency from our neighour (Mr. Harshad patel) & we are fully satisfied with all work.

                                </p>
                                <div class="provider">
                                    <div class="thumb">
                                        <img src="assets/img/test_moni.jpg" alt="Thumb">
                                    </div>
                                    <div class="info">
                                        <h5>Swagat -3 Kuha-Kathwada - Mitesh patel</h5>
                                        <!-- <span>Designer</span> -->
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Item -->
                                <!-- Single Item -->
                                <div class="item">
                                <p>
                                They are very old agency in our Institute & like family with us. Engineering skill is perfact.

                                </p>
                                <div class="provider">
                                    <div class="thumb">
                                        <img src="assets/img/test_moni.jpg" alt="Thumb">
                                    </div>
                                    <div class="info">
                                        <h5>N. I. D. Eng. Kapil Patel</h5>
                                        <!-- <span>Designer</span> -->
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Item -->
                                <!-- Single Item -->
                                <div class="item">
                                <p>
                                I.M. construction has done quality work intine & all the best for futrue.

                                </p>
                                <div class="provider">
                                    <div class="thumb">
                                        <img src="assets/img/test_moni.jpg" alt="Thumb">
                                    </div>
                                    <div class="info">
                                        <h5>Ahmedabad UniverSity - Nivedita Bhatt</h5>
                                        <!-- <span>Designer</span> -->
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Item -->
                                <!-- Single Item -->
                                <div class="item">
                                <p>
                                M/S I.M. construction has done great job as per specification & any time they are ready to do work as per hour client requirement.

                                </p>
                                <div class="provider">
                                    <div class="thumb">
                                        <img src="assets/img/test_moni.jpg" alt="Thumb">
                                    </div>
                                    <div class="info">
                                        <h5>S.P.L.C - V.P. Sankar Sengupta - TaTa NANO - T&R</h5>
                                        <!-- <span>Designer</span> -->
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Item -->
                                <!-- Single Item -->
                                <div class="item">
                                <p>
                                Our Company is fully satisfied and they done all our work. Engineer Mr. Rupesh Shah is always available for our company. Thank You.

                                </p>
                                <div class="provider">
                                    <div class="thumb">
                                        <img src="assets/img/test_moni.jpg" alt="Thumb">
                                    </div>
                                    <div class="info">
                                        <h5>B.O.C. (Linde) India - G.M. - Pradeep Kumar</h5>
                                        <!-- <span>Designer</span> -->
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Item -->
                                <!-- Single Item -->
                                <div class="item">
                                <p>
                                    In our company with full trafic, I.M. construction has done work fully Satisfactory. Road quality is the best.

                                </p>
                                <div class="provider">
                                    <div class="thumb">
                                        <img src="assets/img/test_moni.jpg" alt="Thumb">
                                    </div>
                                    <div class="info">
                                        <h5>Shah Alloys Santej - Engg. Jitesh Shah</h5>
                                        <!-- <span>Designer</span> -->
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Item -->
                                <!-- Single Item -->
                                <div class="item">
                                <p>
                                In our very big area of hospital, they have done civil work without disturbing anything.
                                </p>
                                <div class="provider">
                                    <div class="thumb">
                                        <img src="assets/img/test_moni.jpg" alt="Thumb">
                                    </div>
                                    <div class="info">
                                        <h5>V.S. Hospital- Engg. Bhargav Bhatt</h5>
                                        <!-- <span>Designer</span> -->
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Item -->
                                <!-- Single Item -->
                                <div class="item">
                                <p>
                                With very reasonable rate, they provide perface design & civil infra work for our factory.

                                </p>
                                <div class="provider">
                                    <div class="thumb">
                                        <img src="assets/img/test_moni.jpg" alt="Thumb">
                                    </div>
                                    <div class="info">
                                        <h5>Apollo Industries Chhatral - RajuBhai Patel M.D.</h5>
                                        <!-- <span>Designer</span> -->
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Item -->
                                <!-- Single Item -->
                                <div class="item">
                                <p>
                                Mr. Rupesh is Good sense of civil work. there suggetion is best. Best work.

                                </p>
                                <div class="provider">
                                    <div class="thumb">
                                        <img src="assets/img/test_moni.jpg" alt="Thumb">
                                    </div>
                                    <div class="info">
                                        <h5>M.I.C.A Shela - Sanjay Chavadwani</h5>
                                        <!-- <span>Designer</span> -->
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Item -->
                                <!-- Single Item -->
                                <div class="item">
                                <p>
                                Rupeshbhai is very promising & good person with civil &  road work. All the best.
                                </p>
                                <div class="provider">
                                    <div class="thumb">
                                        <img src="assets/img/test_moni.jpg" alt="Thumb">
                                    </div>
                                    <div class="info">
                                        <h5>I.I.M - Harendrasinh Vadher</h5>
                                        <!-- <span>Designer</span> -->
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Item -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Testimonials Area -->

    <!-- Start Blog Area 
    ============================================= -->
    <div class="blog-area default-padding-bottom bg-gray-responsive">
        <div class="container">
            <!-- <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h4>Blog</h4>
                        <h2>Latest News</h2>
                        <p>
                            While mirth large of on front. Ye he greater related adapted proceed entered an. Through it examine express promise no. Past add size game cold girl off how old
                        </p>
                    </div>
                </div>
            </div> -->
            <div class="blog-items">
                <div class="row">

                    <!-- Blog Grid -->
                    <div class="col-lg-5">
                        <div class="row">
                            <!-- Single Item -->
                            <!-- <div class="col-lg-12 col-md-6 single-item">
                                <div class="item">
                                    <div class="info">
                                        <div class="meta">
                                            <ul>
                                                <li>
                                                    <a href="#">
                                                        <img src="assets/img/100x100.png" alt="Thumb">
                                                        <span>Spark</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <i class="fas fa-calendar"></i> 12 Nov, 2020
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="content">
                                            <h4>
                                                <a href="#">Conditions matter family active mutual put wishes happen. </a>
                                            </h4>
                                            <p>
                                                Replying of dashwood advanced ladyship smallest disposal or. Attempt offices own improve. 
                                            </p>
                                            <a href="#" class="simple">Read More</a>
                                        </div>
                                    </div>
                                </div>
                            </div> -->
                            <!-- End Single Item -->
                            <!-- Single Item -->
                            <!-- <div class="col-lg-12 col-md-6 single-item">
                                <div class="item">
                                    <div class="info">
                                        <div class="meta">
                                            <ul>
                                                <li>
                                                    <a href="#">
                                                        <img src="assets/img/100x100.png" alt="Thumb">
                                                        <span>Spark</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <i class="fas fa-calendar"></i> 12 Nov, 2020
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="content">
                                            <h4>
                                                <a href="#">Conditions matter family active mutual put wishes happen. </a>
                                            </h4>
                                            <a href="#" class="simple">Read More</a>
                                        </div>
                                    </div>
                                </div>
                            </div> -->
                            <!-- End Single Item -->
                        </div>
                    </div>
                    <!-- End Blog Grid  -->

                    <!-- Blog Grid -->

                    <!-- End Blog Grid  -->

                </div>
            </div>
        </div>
    </div>
    <!-- End Blog Area -->
    <!-- Start Footer 
    ============================================= -->
<footer class="bg-dark text-light">
    <div class="container">
        <div class="f-items" style="padding-top: 60px; padding-bottom: 60px;">
            <div class="row">

                <!-- Single Item -->
                <div class="col-lg-5 col-md-12 single-item">
                    <div class="f-item contact">
                        <div class="logo col-lg-10 text-left" style="padding-left: 0px;">
                            <a href="#"><img src="assets/img/logo2.jpg" alt="Logo"></a>
                        </div>
                        <p class="mt-4">I M Construction group based at Ahmedabad-Gujarat established in 2000, are
                            considered to be one of the leading service providers of Many type of services. Inclusive of
                            Building Constructions, Road Construction,.......
                            <!-- Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                            consequat. -->
                        </p>

                    </div>
                </div>
                <!-- End Single Item -->

                <!-- Single Item -->
                <div class="col-lg-2 col-md-12 single-item">
                    <div class="f-item link">
                        <h4 class="widget-title">Useful Links</h4>
                        <ul>
                            <li>
                                <a href="index.php">Home</a>
                            </li>
                            <li>
                                <a href="about-us.php">About Us</a>
                            </li>
                            <!-- <li>
                                <a href="#">Service</a>
                            </li> -->
                            <li>
                                <a href="client_list.php">Client List</a>
                            </li>
                            <li>
                                <a href="gallery.php">Gallery</a>
                            </li>
                            <!-- <li>
                                <a href="#">Inquiry</a>
                            </li> -->
                            <li>
                                <a href="contact.php">Contact Us</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- End Single Item -->


                <!-- Single Item -->
                <div class="col-lg-2 col-md-12 single-item">
                    <div class="f-item link">
                        <h4 class="widget-title">Service</h4>
                        <ul>
                            <li>
                                <a href="ind-bld.php">Industrial & Building Constructions</a>
                            </li>
                            <li>
                                <a href="road.php">Road
                                    Construction</a>
                            </li>
                            <li>
                                <a href="water.php">Structural
                                    repairing & Waterproofing</a>
                            </li>
                            <!-- <li>
                                <a href="#">Service-4</a>
                            </li> -->
                        </ul>
                    </div>
                </div>
                <!-- End Single Item -->

                <!-- Single Item -->
                <div class="col-lg-3 col-md-12 single-item">
                    <div class="f-item contact">
                        <h4 class="widget-title">Contact Us</h4>
                        <p>

                        </p>
                        <ul>
                            <li>
                                <a href="https://www.google.com/maps?ll=23.027063,72.523487&z=16&t=m&hl=en&gl=IN&mapclient=embed&cid=11240422690339418904"><i class="fas fa-map-marker-alt"></i>
                                19, OM Tower (L.L.)
                                B/s. Star Bazaar, Nr. Jodhpur Cross Road,
                                Satellite, Ahmedabad-380015.</a>
                            </li>
                            <li>
                                <a href="mailto: im0066@yahoo.co.in"><i class="fas fa-envelope-open"></i>
                                    im0066@yahoo.co.in</a>
                                <!-- <a href="mailto: riprup@gmail.com"></i>
                                    riprup@gmail.com</a> -->
                            </li>
                            <li>
                                <a href="tel:9898441117"><i class="fas fa-phone"></i>
                                    +91-98984 41117</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- End Single Item -->
                <!-- Single Item -->
                <!-- <div class="col-lg-4 col-md-6 single-item">
                        <div class="f-item opening-hours">
                            <h4 class="widget-title">Opening Hours</h4>
                            <ul>
                                <li> 
                                    <span>Sat - Sun :  </span>
                                    <div class="float-right"> 8.00 - 14.30</div>
                                </li>
                                <li> 
                                    <span>Monday :</span>
                                    <div class="float-right"> 11.00 - 16.00</div>
                                </li>
                                <li> 
                                    <span>Wed - Thu :</span>
                                    <div class="float-right"> 7.00 - 15.30</div>
                                </li>
                                <li> 
                                    <span> Friday : </span>
                                    <div class="float-right closed"> Closed </div>
                                </li>
                            </ul>
                        </div>
                    </div> -->
                <!-- End Single Item -->
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <div class="col-lg-12" style="text-align:center;">
                    <p>&copy; 2023 I M Construction All rights reserved. | Design By<a target="_blank"
                            href="https://www.mart2global.com/" ;> Mart2global</a></p>
                </div>

            </div>
        </div>
    </div>

</footer>
<script async src='https://d2mpatx37cqexb.cloudfront.net/delightchat-whatsapp-widget/embeds/embed.min.js'></script>
        <script>
          var wa_btnSetting = {"btnColor":"#16BE45","ctaText":"","cornerRadius":40,"marginBottom":20,"marginLeft":20,"marginRight":20,"btnPosition":"right","whatsAppNumber":"919898441117","welcomeMessage":"Hello","zIndex":999999,"btnColorScheme":"light"};
          window.onload = () => {
            _waEmbed(wa_btnSetting);
          };
        </script>
          <!-- Fixed Shape -->

    <!-- <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <p>&copy; Copyright 2019. All Rights Reserved by <a href="#">validthemes</a></p>
                    </div>
                    <div class="col-lg-6 text-right">
                        <ul>
                            <li>
                                <a href="#">Terms of user</a>
                            </li>
                            <li>
                                <a href="#">License</a>
                            </li>
                            <li>
                                <a href="#">Support</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div> -->
    <!-- Start Footer Bottom -->

    <!-- <div class="fixed-shape">
            <img src="assets/img/shape/3.svg" alt="Shape">
        </div> -->
    <!-- End Fixed Shape -->
    </footer>
    <!-- End Footer -->

    <!-- jQuery Frameworks
    ============================================= -->
    <script src="assets/js/jquery-1.12.4.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/equal-height.min.js"></script>
    <script src="assets/js/jquery.appear.js"></script>
    <script src="assets/js/jquery.easing.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/modernizr.custom.13711.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/progress-bar.min.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/count-to.js"></script>
    <script src="assets/js/bootsnav.js"></script>
    <script src="assets/js/main.js"></script>

</body>

</html>